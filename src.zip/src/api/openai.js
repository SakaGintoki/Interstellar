/**
 * Fetches a response from our OWN backend API endpoint.
 * @param {string} message - The user's message.
 * @param {Array} history - The chat history (Array of {role, content}).
 * @param {string} scale - The current scene scale (e.g., 'atom', 'dna').
 * @returns {Promise<string>} - The AI's response message.
 */
export async function fetchLocalAIResponse(message, history, scale) {
  try {
    const response = await fetch('/api/chat', { // Memanggil endpoint backend
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message, history, scale }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Server error');
    }

    const data = await response.json();
    return data.content;

  } catch (error) {
    console.error('Error fetching from local API:', error);
    throw new Error(`Failed to connect to AI: ${error.message}`);
  }
}